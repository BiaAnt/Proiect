
PROJECT:Healthcare Appointment Booking System

Scop: Aceasta aplicatie permite gestionarea programarilor medicale intr-o clinica.

Functionalitati:
1.Afisarea intervalelor orare disponibile pentru servicii medicale.
2.Rezervarea de programari de catre pacienti.
3.Calendar pentru doctori (cu programari si intervale indisponibile)
4.Anulare sau reprogramare de programari
5.Trimiterea de notificari si remindere
6.Accesul doctorilor la istoricul medical al pacientilor
7.Gestionarea serviciilor medicale (ex: cardiologie, dermatologie)

Rulare:
Functionalitatile sunt implementate in folderul IMPLEMENTATIONS, iar CONTROLLERS face ca
aplicatia sa ruleze in Swagger.

Erori posibil de intalnit:
Swagger uneori duce la warnings in program.
