﻿using BusinessLayer.Implementations;
using BusinessLayer.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AppointmentManagerController : ControllerBase
    {
        private readonly IAppointmentManagementService _appointmentManagerService;
        [HttpPost("cancel")]
        public IActionResult Cancel(Guid appointmentId, Guid patientId)
        {
            _appointmentManagerService.CancelAppointment(appointmentId, patientId);
            return Ok("Programare anulată.");
        }

        [HttpPost("reschedule")]
        public IActionResult Reschedule(Guid appointmentId, Guid patientId, DateTime newDate)
        {
            _appointmentManagerService.RescheduleAppointment(appointmentId, newDate, patientId);
            return Ok("Programare reprogramată.");
        }
    }
}
