﻿using BusinessLayer.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MedicalRecordController : ControllerBase
    {
        private readonly IMedicalRecordService _medicalService;

        public MedicalRecordController(IMedicalRecordService medicalService)
        {
            _medicalService = medicalService;
        }

        [HttpGet("record/{patientId}")]
        public IActionResult GetMedicalRecord(Guid patientId)
        {
            var record = _medicalService.GetPatientMedicalRecord(patientId);
            return Ok(record);
        }

        [HttpGet("appointments/{patientId}")]
        public IActionResult GetAppointmentHistory(Guid patientId)
        {
            var history = _medicalService.GetAppointmentHistory(patientId);
            return Ok(history);
        }
    }
}
