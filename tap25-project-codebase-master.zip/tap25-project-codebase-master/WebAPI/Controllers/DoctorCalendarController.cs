﻿using Microsoft.AspNetCore.Mvc;
using BusinessLayer.Interfaces;
using BusinessLayer.ModelDTOs;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DoctorCalendarController : ControllerBase
    {
        private readonly IDoctorCalendarService _doctorCalendarService;

        [HttpGet("calendar/{doctorId}")]
        public IActionResult GetCalendar(Guid doctorId, DateTime date)
        {
            var calendar = _doctorCalendarService.GetDoctorCalendar(doctorId, date);
            return Ok(calendar);
        }
    }
}
