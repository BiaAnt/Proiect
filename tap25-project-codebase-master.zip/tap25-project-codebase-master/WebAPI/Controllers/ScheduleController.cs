﻿using BusinessLayer.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScheduleController : ControllerBase
    {
        private readonly IScheduleService _scheduleService;

        public ScheduleController(IScheduleService scheduleService)
        {
            _scheduleService = scheduleService;
        }

        [HttpGet("available-slots/by-service/{serviceId}")]
        public IActionResult GetAvailableSlots(Guid serviceId, DateTime date)
        {
            var result = _scheduleService.GetAvailableSlotsForService(serviceId, date);
            return Ok(result);
        }
    }
}
