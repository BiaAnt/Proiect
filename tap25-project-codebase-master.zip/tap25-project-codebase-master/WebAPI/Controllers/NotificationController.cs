﻿using BusinessLayer.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace WebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NotificationController : ControllerBase
    {
        private readonly INotificationService _notificationService;

        public NotificationController(INotificationService notificationService)
        {
            _notificationService = notificationService;
        }

        [HttpPost("reminder/{appointmentId}")]
        public IActionResult SendReminder(Guid appointmentId)
        {
            _notificationService.SendAppointmentReminder(appointmentId);
            return Ok("Reminder trimis.");
        }
    }
}
