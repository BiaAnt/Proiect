﻿using DataAccess.Models;
using Microsoft.EntityFrameworkCore;

namespace DataAccess
{
    public class MyDbContext : DbContext
    {
        // dotnet ef migrations add <migration-name>
        // dotnet ef database update

        private readonly string _windowsConnectionString = @"Server=.\SQLExpress;Database=TAP_DB_Project;Trusted_Connection=True;TrustServerCertificate=true";

        public DbSet<User> Users { get; set; }
        public DbSet<Doctor> Doctors { get; set; }
        public DbSet<Appointment> Appointments { get; set; }
        public DbSet<DoctorCalendar> DoctorCalendars { get; set; }

        public DbSet<DoctorService> DoctorServices { get; set; }

        public DbSet<MedicalHistory> MedicalHistories { get; set; }
        public DbSet<MedicalService> MedicalServices { get; set; }
        public DbSet<Notification> Notifications { get; set; }
        public DbSet<Patient> Patients { get; set; }
        public DbSet<Service> Services { get; set; }
        public DbSet<UnavailablePeriod> UnavailablePeriods { get; set; }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(_windowsConnectionString);
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Appointment>()
            .HasOne(a => a.Doctor)
            .WithMany(d => d.Appointments)
            .HasForeignKey(a => a.DoctorId);

            builder.Entity<Appointment>()
            .HasOne(a => a.Patient)
            .WithMany(p => p.Appointments)
            .HasForeignKey(a => a.PatientId);


            builder.Entity<Appointment>()
            .HasOne(a => a.Service)
            .WithMany(s => s.Appointments)
            .HasForeignKey(a => a.ServiceId);

            builder.Entity<Patient>()
            .HasOne(p => p.History)
            .WithOne(m => m.Patient)
            .HasForeignKey<MedicalHistory>(m => m.PatientId);


            builder.Entity<UnavailablePeriod>()
            .HasOne(u => u.Doctor)
            .WithMany(d => d.UnavailablePeriods)
            .HasForeignKey(u => u.DoctorId);


            builder.Entity<DoctorService>()
               .HasKey(ds => new { ds.DoctorId, ds.ServiceId });

            builder.Entity<DoctorService>()
                .HasOne(ds => ds.Doctor)
                .WithMany(d => d.DoctorServices)
                .HasForeignKey(ds => ds.DoctorId);

            builder.Entity<DoctorService>()
                .HasOne(ds => ds.Service)
                .WithMany(s => s.DoctorServices)
                .HasForeignKey(ds => ds.ServiceId);


        }


        private void Seed(ModelBuilder builder)
        {
        builder.Entity<Patient>()
                .HasData(
                    new Patient
                    {
                        Id = new Guid("a1111111-1111-1111-1111-111111111111"),
                        Name = "Ana Popescu",
                        Email = "ana@example.com",
                        Password = "ana123",
                        
                        DateOfBirth = new DateTime(1990, 5, 15)
                    },
        new Patient
        {
            Id = new Guid("a2222222-2222-2222-2222-222222222222"),
            Name = "Mihai Ionescu",
            Email = "mihai@example.com",
            Password = "mihai123",
            DateOfBirth = new DateTime(1985, 10, 20)
        },
        new Patient
        {
            Id = new Guid("a3333333-3333-3333-3333-333333333333"),
            Name = "Elena Marin",
            Email = "elena@example.com",
            Password = "elena123",
            DateOfBirth = new DateTime(1995, 3, 5)
        }
                    );


         builder.Entity<Doctor>()
            .HasData(
                new Doctor
                {
                    Id = new Guid("d1111111-1111-1111-1111-111111111111"),
                    Name = "Dr. Andrei Popa",
                    Email = "andrei.popa@clinic.com",
                    Password = "andrei123",
                    Specialization = "Cardiologie"
                },
        new Doctor
        {
            Id = new Guid("d2222222-2222-2222-2222-222222222222"),
            Name = "Dr. Ioana Vlad",
            Email = "ioana.vlad@clinic.com",
            Password = "ioana123",
            Specialization = "Dermatologie"
        },
        new Doctor
        {
            Id = new Guid("d3333333-3333-3333-3333-333333333333"),
            Name = "Dr. Mihai Georgescu",
            Email = "mihai.georgescu@clinic.com",
            Password = "mihai123",
            Specialization = "Pediatrie"
        }
            );

            builder.Entity<Appointment>().HasData(
            new Appointment
            {
                Id = new Guid("a0000001-0000-0000-0000-000000000001"),
                Date = DateTime.Today.AddDays(1).AddHours(10),
                Status = "Scheduled"
            },
            new Appointment
            {
                Id = new Guid("a0000002-0000-0000-0000-000000000002"),
                Date = DateTime.Today.AddDays(2).AddHours(11),
                Status = "Scheduled"
            },
            new Appointment
            {
                Id = new Guid("a0000003-0000-0000-0000-000000000003"),
                Date = DateTime.Today.AddDays(3).AddHours(9),
                Status = "Scheduled"
            }
            );

            builder.Entity<Service>().HasData(
        new Service
        {
            Id = new Guid("s1111111-1111-1111-1111-111111111111"),
            Name = "Cardiologie",
            Duration = new TimeSpan(0, 30, 0) // 30 minute
        },
        new Service
        {
            Id = new Guid("s2222222-2222-2222-2222-222222222222"),
            Name = "Dermatologie",
            Duration = new TimeSpan(0, 20, 0) // 20 minute
        },
        new Service
        {
            Id = new Guid("s3333333-3333-3333-3333-333333333333"),
            Name = "Pediatrie",
            Duration = new TimeSpan(0, 40, 0) // 40 minute
        }
    );

            builder.Entity<MedicalHistory>().HasData(
        new MedicalHistory
        {
            Id = new Guid("h1111111-1111-1111-1111-111111111111"),
            ChronicConditions = "Hipertensiune",
            Allergies = "Penicilină",
            Medications = "Ramipril",
            Notes = "Monitorizare lunară",
            PatientId = new Guid("a1111111-1111-1111-1111-111111111111")
        },
        new MedicalHistory
        {
            Id = new Guid("h2222222-2222-2222-2222-222222222222"),
            ChronicConditions = "Diabet de tip 2",
            Allergies = "Niciuna",
            Medications = "Metformin",
            Notes = "Control trimestrial",
            PatientId = new Guid("a2222222-2222-2222-2222-222222222222")
        },
        new MedicalHistory
        {
            Id = new Guid("h3333333-3333-3333-3333-333333333333"),
            ChronicConditions = "Astm",
            Allergies = "Polen",
            Medications = "Salbutamol",
            Notes = "-",
            PatientId = new Guid("a3333333-3333-3333-3333-333333333333")
        }
    );

        }
    }
}
