﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class Service
    {
        public Service(Guid id, string name, TimeSpan duration, ICollection<DoctorService> doctorServices, ICollection<Appointment> appointments)
        {
            Id = id;
            Name = name;
            Duration = duration;
            DoctorServices = doctorServices;
            Appointments = appointments;
        }
        public Service() { }

        public Guid Id { get; set; }

        public string Name { get; set; }

        public TimeSpan Duration { get; set; }

        public ICollection<DoctorService> DoctorServices { get; set; } = new List<DoctorService>();
        public ICollection<Appointment> Appointments { get; set; }
    }
}
