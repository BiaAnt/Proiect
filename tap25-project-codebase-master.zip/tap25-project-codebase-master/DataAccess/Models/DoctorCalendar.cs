﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class DoctorCalendar
    {

        public DoctorCalendar() { }
        public Guid Id { get; set; }
        public Guid DoctorId { get; set; }
        public Doctor Doctor { get; set; }
        public List<Appointment> Appointments { get; set; } = new();
        public List<DateTime> AvailableSlots { get; set; } = new();
    }
}
