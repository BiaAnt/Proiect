﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class Doctor : User
    {
        public Doctor() { }
        public string Specialization { get; set; }
        public ICollection<Appointment> Appointments { get; set; }
        public ICollection<DoctorService> DoctorServices { get; set; } = new List<DoctorService>();
        public ICollection<UnavailablePeriod> UnavailablePeriods { get; set; } = new List<UnavailablePeriod>();
    }
}
