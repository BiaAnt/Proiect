﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class Patient:User
    {
        public Patient(DateTime dateOfBirth, ICollection<Appointment> appointments, MedicalHistory history)
        {
            DateOfBirth = dateOfBirth;
            Appointments = appointments;
            History = history;
        }
        public Patient() { }
        public DateTime DateOfBirth { get; set; }
        public ICollection<Appointment> Appointments { get; set; }
        public MedicalHistory History { get; set; }
    }
}
