﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class MedicalHistory
    {
        public MedicalHistory(Guid id, string chronicConditions, string allergies, string medications, string notes, Guid patientId, Patient patient)
        {
            Id = id;
            ChronicConditions = chronicConditions;
            Allergies = allergies;
            Medications = medications;
            Notes = notes;
            PatientId = patientId;
            Patient = patient;
        }
        public MedicalHistory() { }

        public Guid Id { get; set; }
        public string ChronicConditions { get; set; }
        public string Allergies { get; set; }
        public string Medications { get; set; }
        public string Notes { get; set; }

        // legatura cu pacientul
        public Guid PatientId { get; set; }
        public Patient Patient { get; set; }
    }
}
