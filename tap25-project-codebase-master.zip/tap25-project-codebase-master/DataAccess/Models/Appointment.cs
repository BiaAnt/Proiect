﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class Appointment
    {
        public Appointment(Guid id, DateTime date, string status, Guid patientId, Patient patient, Guid doctorId, Doctor doctor, Guid serviceId, Service service)
        {
            Id = id;
            Date = date;
            Status = status;
            PatientId = patientId;
            Patient = patient;
            DoctorId = doctorId;
            Doctor = doctor;
            ServiceId = serviceId;
            Service = service;
        }
        public Appointment() { }
        public Guid Id { get; set; }                     
        public DateTime Date { get; set; }             
        public String Status { get; set; }   

        // relatii cu alte clase
        public Guid PatientId { get; set; }
        public Patient Patient { get; set; }

        public Guid DoctorId { get; set; }
        public Doctor Doctor { get; set; }

        public Guid ServiceId { get; set; }
        public Service Service { get; set; }
    }
}
