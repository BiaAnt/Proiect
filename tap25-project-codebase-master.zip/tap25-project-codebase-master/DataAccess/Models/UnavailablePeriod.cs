﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class UnavailablePeriod
    {
        public UnavailablePeriod(Guid id, Guid doctorId, Doctor doctor, DateTime from, DateTime to, string reason)
        {
            Id = id;
            DoctorId = doctorId;
            Doctor = doctor;
            From = from;
            To = to;
            Reason = reason;
        }
        public UnavailablePeriod() { }
        public Guid Id { get; set; }

        public Guid DoctorId { get; set; }
        public Doctor Doctor { get; set; }

        public DateTime From { get; set; }
        public DateTime To { get; set; }

        public string Reason { get; set; }
    }
}
