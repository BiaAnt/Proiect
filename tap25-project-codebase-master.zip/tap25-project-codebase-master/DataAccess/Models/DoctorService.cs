﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class DoctorService
    {
        public DoctorService() { }
        public Guid DoctorId { get; set; }
        public Doctor Doctor { get; set; }

        public Guid ServiceId { get; set; }
        public Service Service { get; set; }
    }
}
