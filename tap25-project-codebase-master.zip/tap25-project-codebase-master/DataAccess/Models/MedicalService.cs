﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class MedicalService
    {
        public MedicalService(Guid id, string serviceName, TimeSpan duration, string requiredSpecialization, ICollection<Doctor> doctors)
        {
            Id = id;
            ServiceName = serviceName;
            Duration = duration;
            RequiredSpecialization = requiredSpecialization;
            Doctors = doctors;
        }
        public MedicalService() { }

        public Guid Id { get; set; }
        public string ServiceName { get; set; }
        public TimeSpan Duration { get; set; }
        public string RequiredSpecialization { get; set; }
        public ICollection<Doctor> Doctors { get; set; }
    }
}
