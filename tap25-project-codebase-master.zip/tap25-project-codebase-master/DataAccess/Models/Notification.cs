﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Models
{
    public class Notification
    {
        public Notification(Guid id, string recipient, string message, DateTime sendDate, string type)
        {
            Id = id;
            Recipient = recipient;
            Message = message;
            SendDate = sendDate;
            Type = type;
        }
        public Notification() { }
        public Guid Id { get; set; }
        public string Recipient { get; set; }  
        public string Message { get; set; }
        public DateTime SendDate { get; set; }
        public string Type { get; set; }
    }
}
