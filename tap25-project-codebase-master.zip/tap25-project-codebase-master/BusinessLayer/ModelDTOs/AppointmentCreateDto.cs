﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.ModelDTOs
{
    public class AppointmentCreateDto
    {
        public Guid DoctorId { get; set; }
        public Guid PatientId { get; set; }
        public Guid ServiceId { get; set; }  
        public DateTime Date { get; set; }  
    }
}
