﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.ModelDTOs
{
    public class AppointmentCreateDto
    {
        public Guid DoctorId { get; set; }
        public Guid PatientId { get; set; }
        public Guid ServiceId { get; set; }  // Dacă vrei să legi de un anumit serviciu
        public DateTime Date { get; set; }   // Ora la care pacientul dorește programarea
    }
}
