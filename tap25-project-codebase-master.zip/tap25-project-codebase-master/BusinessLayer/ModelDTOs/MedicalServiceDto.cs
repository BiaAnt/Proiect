﻿using DataAccess.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.ModelDTOs
{
    public class MedicalServiceDto
    {
        public Guid? Id { get; set; }
        public string ServiceName { get; set; }
        public TimeSpan Duration { get; set; }
        public string RequiredSpecialization { get; set; }
        public ICollection<DoctorDto> Doctors { get; set; }
    }
}
