﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.ModelDTOs
{
    public class MedicalHistoryDto
    {
        public Guid? Id { get; set; }
        public string Name { get; set; }
        public string ChronicConditions { get; set; }
        public string Allergies { get; set; }
        public string Medications { get; set; }
        public string Notes { get; set; }
        public Guid PatientId { get; set; }
    }
}
