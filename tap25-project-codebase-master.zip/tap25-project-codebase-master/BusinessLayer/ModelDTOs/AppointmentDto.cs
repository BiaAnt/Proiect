﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.ModelDTOs
{
    public class AppointmentDto
    {
        public Guid Id { get; set; }

        public DateTime Date { get; set; }

        public string Status { get; set; }

        public Guid PatientId { get; set; }
        public string PatientName { get; set; }  

        public Guid DoctorId { get; set; }
        public string DoctorName { get; set; }   

        public string ServiceName { get; set; }      

    }
}
