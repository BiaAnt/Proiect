﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.ModelDTOs
{
    public class DoctorCalendarDto
    {
        public Guid DoctorId { get; set; }
        public string DoctorName { get; set; }
        public string Specialization { get; set; }
        public List<AppointmentDto> Appointments { get; set; } = new();

        public List<DateTime> AvailableSlots { get; set; } = new();
    }
}
