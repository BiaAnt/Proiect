﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces
{
    public interface IAppointmentManagementService
    {
        void CancelAppointment(Guid appointmentId, Guid patientId);

        void RescheduleAppointment(Guid appointmentId, DateTime newDate, Guid patientId);

    }
}
