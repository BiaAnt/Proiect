﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces
{
    public interface INotificationService
    {
        void SendAppointmentReminder(Guid appointmentId);

        void NotifyPatient(Guid patientId, string message);

        void NotifyDoctor(Guid doctorId, string message);
    }
}
