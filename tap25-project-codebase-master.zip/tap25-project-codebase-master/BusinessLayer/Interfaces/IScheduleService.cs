﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces
{
    public interface IScheduleService
    {
        List<DateTime> GetAvailableSlots(Guid doctorId, DateTime forDate, TimeSpan slotDuration);

        Dictionary<Guid, List<DateTime>> GetAvailableSlotsBySpecialization(string specialization, DateTime forDate);

        Dictionary<Guid, List<DateTime>> GetAvailableSlotsForService(Guid serviceId, DateTime forDate);
    }
}
