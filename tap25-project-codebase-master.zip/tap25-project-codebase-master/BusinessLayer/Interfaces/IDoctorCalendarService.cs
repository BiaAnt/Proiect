﻿using BusinessLayer.ModelDTOs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces
{
    public interface IDoctorCalendarService
    {
        
        DoctorCalendarDto GetDoctorCalendar(Guid doctorId, DateTime forDate);

        
        List<AppointmentDto> GetAppointmentsForDoctor(Guid doctorId, DateTime fromDate, DateTime toDate);

        void AddUnavailablePeriod(Guid doctorId, DateTime from, DateTime to, string reason);

    }
}
