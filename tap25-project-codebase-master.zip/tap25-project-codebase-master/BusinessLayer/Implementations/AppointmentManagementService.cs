﻿using BusinessLayer.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccess.Models;
using DataAccess.Repository;

namespace BusinessLayer.Implementations
{
    public class AppointmentManagementService: IAppointmentManagementService 
    {
        private readonly IRepository<Appointment> _appointmentRepository;
        private readonly IRepository<Service> _serviceRepository;
        private readonly IScheduleService _scheduleService;

        public AppointmentManagementService(
            IRepository<Appointment> appointmentRepository,
            IRepository<Service> serviceRepository,
            IScheduleService scheduleService)
        {
            _appointmentRepository = appointmentRepository;
            _serviceRepository = serviceRepository;
            _scheduleService = scheduleService;
        }

        public void CancelAppointment(Guid appointmentId, Guid patientId)
        {
            
            var appointment = _appointmentRepository.GetById(appointmentId);
            if (appointment == null)
                throw new ArgumentException("Programarea nu a fost găsită.");

            
            if (appointment.PatientId != patientId)
                throw new UnauthorizedAccessException("Nu poți anula o programare care nu îți aparține.");

            
            if (appointment.Date <= DateTime.Now)
                throw new InvalidOperationException("Nu poți anula o programare trecută sau în curs.");

            
            appointment.Status = "Canceled";

            _appointmentRepository.Update(appointment);
            _appointmentRepository.SaveChanges();
        }

        public void RescheduleAppointment(Guid appointmentId, DateTime newDate, Guid patientId)
        {
           
            var appointment = _appointmentRepository.GetById(appointmentId);
            if (appointment == null)
                throw new ArgumentException("Programarea nu a fost găsită.");

            
            if (appointment.PatientId != patientId)
                throw new UnauthorizedAccessException("Nu poți modifica o programare care nu îți aparține.");

            
            if (newDate <= DateTime.Now)
                throw new InvalidOperationException("Nu poți reprograma o programare în trecut.");

           
            var service = appointment.Service ?? _serviceRepository.GetById(appointment.ServiceId);
            if (service == null)
                throw new ArgumentException("Serviciul asociat programării nu a fost găsit.");

            var availableSlots = _scheduleService.GetAvailableSlots(appointment.DoctorId, newDate.Date, service.Duration);

            if (!availableSlots.Contains(newDate))
                throw new InvalidOperationException("Noul slot este deja ocupat.");

            
            appointment.Date = newDate;
            appointment.Status = "Rescheduled";

            _appointmentRepository.Update(appointment);
            _appointmentRepository.SaveChanges();
        }

    }
}
