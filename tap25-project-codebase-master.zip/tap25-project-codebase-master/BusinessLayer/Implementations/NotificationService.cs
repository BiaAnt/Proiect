﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer.Interfaces;
using DataAccess.Models;
using DataAccess.Repository;

namespace BusinessLayer.Implementations
{
    public class NotificationService: INotificationService
    {
        private readonly IRepository<Appointment> _appointmentRepository;

        public NotificationService(IRepository<Appointment> appointmentRepository)
        {
            _appointmentRepository = appointmentRepository;
        }

        public void SendAppointmentReminder(Guid appointmentId)
        {
            var appointment = _appointmentRepository.GetById(appointmentId);

            if (appointment == null)
                throw new ArgumentException("Programarea nu a fost găsită.");

            if (appointment.Patient == null)
                throw new InvalidOperationException("Pacientul asociat nu este disponibil.");

            var patientName = appointment.Patient.Name;
            var appointmentDate = appointment.Date;

            // Simulare notificare
            Console.WriteLine($"[Reminder] Pentru: {patientName} - Ai o programare pe {appointmentDate:dddd, dd MMM yyyy HH:mm}");
        }

        public void NotifyPatient(Guid patientId, string message)
        {
            Console.WriteLine($"[Notificare pacient] ID: {patientId} - {message}");
        }

        public void NotifyDoctor(Guid doctorId, string message)
        {
            Console.WriteLine($"[Notificare doctor] ID: {doctorId} - {message}");
        }
    }
}
