﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer.Interfaces;
using BusinessLayer.ModelDTOs;
using DataAccess.Models;
using DataAccess.Repository;

namespace BusinessLayer.Implementations
{
    public class DoctorCalendarService:IDoctorCalendarService
    {
        private readonly IRepository<Doctor> _doctorRepository;
        private readonly IRepository<Appointment> _appointmentRepository;
        private readonly IRepository<UnavailablePeriod> _unavailableRepository;
        private readonly IScheduleService _scheduleService;

        public DoctorCalendarService(
            IRepository<Doctor> doctorRepository,
            IRepository<Appointment> appointmentRepository,
            IScheduleService scheduleService)
        {
            _doctorRepository = doctorRepository;
            _appointmentRepository = appointmentRepository;
            _scheduleService = scheduleService;
        }
        public DoctorCalendarDto GetDoctorCalendar(Guid doctorId, DateTime forDate)
        {
            
            var doctor = _doctorRepository.GetById(doctorId);
            if (doctor == null)
                throw new ArgumentException("Doctorul nu a fost găsit.");

            
            var appointments = _appointmentRepository
                .GetAll()
                .Where(a => a.DoctorId == doctorId && a.Date.Date == forDate.Date)
                .ToList();

            
            var appointmentDtos = appointments.Select(a => new AppointmentDto
            {
                Id = a.Id,
                Date = a.Date,
                Status = a.Status,
                PatientId = a.PatientId,
                PatientName = a.Patient?.Name ?? "N/A",
                ServiceName = a.Service?.Name ?? "Consultație"
            }).ToList();

            
            var availableSlots = _scheduleService.GetAvailableSlots(doctorId, forDate, TimeSpan.FromMinutes(30));

            
            return new DoctorCalendarDto
            {
                DoctorId = doctor.Id,
                DoctorName = doctor.Name,
                Specialization = doctor.Specialization,
                Appointments = appointmentDtos,
                AvailableSlots = availableSlots
            };
        }

        public List<AppointmentDto> GetAppointmentsForDoctor(Guid doctorId, DateTime fromDate, DateTime toDate)
        {
            
            var appointments = _appointmentRepository
                .GetAll()
                .Where(a => a.DoctorId == doctorId && a.Date >= fromDate && a.Date <= toDate)
                .ToList();

            
            var appointmentDtos = appointments.Select(a => new AppointmentDto
            {
                Id = a.Id,
                Date = a.Date,
                Status = a.Status,
                PatientId = a.PatientId,
                DoctorId = a.DoctorId,
                PatientName = a.Patient?.Name ?? "N/A",
                DoctorName = a.Doctor?.Name ?? "N/A",
                ServiceName = a.Service?.Name ?? "Consultație",
            }).ToList();

            return appointmentDtos;
        }

        public void AddUnavailablePeriod(Guid doctorId, DateTime from, DateTime to, string reason)
        {
            if (from >= to)
                throw new ArgumentException("Perioada este invalidă.");

            var doctor = _doctorRepository.GetById(doctorId);
            if (doctor == null)
                throw new ArgumentException("Doctorul nu există.");

            var newPeriod = new UnavailablePeriod
            {
                Id = Guid.NewGuid(),
                DoctorId = doctorId,
                From = from,
                To = to,
                Reason = reason
            };

            _unavailableRepository.Add(newPeriod);
            _unavailableRepository.SaveChanges();
        }
    }
}
