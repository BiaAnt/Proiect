﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer.Interfaces;
using BusinessLayer.ModelDTOs;
using DataAccess.Models;
using DataAccess.Repository;


namespace BusinessLayer.Implementations
{
    public class AppointmentService:IAppointmentService
    {
        private readonly IRepository<Appointment> _appointmentRepository;
        private readonly IRepository<Doctor> _doctorRepository;
        private readonly IRepository<Patient> _patientRepository;
        private readonly IRepository<Service> _serviceRepository;
        private readonly IScheduleService _scheduleService;

        public AppointmentService(
           IRepository<Appointment> appointmentRepository,
           IRepository<Doctor> doctorRepository,
           IRepository<Patient> patientRepository,
           IRepository<Service> serviceRepository,
           IScheduleService scheduleService)
        {
            _appointmentRepository = appointmentRepository;
            _doctorRepository = doctorRepository;
            _patientRepository = patientRepository;
            _serviceRepository = serviceRepository;
            _scheduleService = scheduleService;
        }

        public void BookAppointment(AppointmentCreateDto dto)
        {
            // 1. Verificări de existență
            var doctor = _doctorRepository.GetById(dto.DoctorId);
            if (doctor == null) throw new ArgumentException("Doctorul nu există.");

            var patient = _patientRepository.GetById(dto.PatientId);
            if (patient == null) throw new ArgumentException("Pacientul nu există.");

            var service = _serviceRepository.GetById(dto.ServiceId);
            if (service == null) throw new ArgumentException("Serviciul nu există.");

            // 2. Verificare dacă slotul este disponibil
            var availableSlots = _scheduleService.GetAvailableSlots(dto.DoctorId, dto.Date.Date, service.Duration);
            if (!availableSlots.Contains(dto.Date))
            {
                throw new InvalidOperationException("Slotul selectat este deja ocupat.");
            }

            // 3. Creăm programarea
            var appointment = new Appointment
            {
                Id = Guid.NewGuid(),
                DoctorId = dto.DoctorId,
                PatientId = dto.PatientId,
                ServiceId = dto.ServiceId,
                Date = dto.Date,
                Status = "Scheduled"
            };

            _appointmentRepository.Add(appointment);
            _appointmentRepository.SaveChanges();
        }
    }
}
