﻿using BusinessLayer.Interfaces;
using BusinessLayer.ModelDTOs;
using DataAccess;
using DataAccess.Models;
using DataAccess.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Implementations
{
    
    public class MedicalRecordService : IMedicalRecordService
        {
            private readonly IRepository<MedicalHistory> _medicalHistoryRepository;
            private readonly IRepository<Patient> _patientRepository;
            private readonly IRepository<Appointment> _appointmentRepository;
        private readonly MyDbContext _context;

        public MedicalRecordService(
                IRepository<MedicalHistory> medicalHistoryRepository,
                IRepository<Patient> patientRepository,
                IRepository<Appointment> appointmentRepository,
                MyDbContext context)
            {
                _medicalHistoryRepository = medicalHistoryRepository;
                _patientRepository = patientRepository;
            _appointmentRepository = appointmentRepository;
            _context = context;
        }

        public MedicalHistoryDto GetPatientMedicalRecord(Guid patientId)
            {
                // 1. Verificăm dacă pacientul există
                var patient = _patientRepository.GetById(patientId);
                if (patient == null)
                    throw new ArgumentException("Pacientul nu a fost găsit.");

                // 2. Căutăm fișa medicală
                var history = _medicalHistoryRepository
                    .GetAll()
                    .FirstOrDefault(h => h.PatientId == patientId);

                if (history == null)
                    throw new InvalidOperationException("Fișa medicală nu a fost găsită pentru acest pacient.");

                // 3. Mapăm în DTO
                return new MedicalHistoryDto
                {
                    Id = history.Id,
                    PatientId = history.PatientId,
                    Name = patient.Name,
                    ChronicConditions = history.ChronicConditions,
                    Allergies = history.Allergies,
                    Medications = history.Medications,
                    Notes = history.Notes
                };
            }

        public List<AppointmentDto> GetAppointmentHistory(Guid patientId)
        {
            // 1. Verificăm dacă pacientul există
            var patient = _patientRepository.GetById(patientId);
            if (patient == null)
                throw new ArgumentException("Pacientul nu a fost găsit.");

            // 2. Luăm toate programările pacientului
            var appointments = _appointmentRepository
                .GetAll()
                .Where(a => a.PatientId == patientId)
                .OrderByDescending(a => a.Date)
                .ToList();

            // 3. Mapăm în DTO-uri
            var appointmentDtos = appointments.Select(a => new AppointmentDto
            {
                Id = a.Id,
                Date = a.Date,
                Status = a.Status,
                PatientId = a.PatientId,
                DoctorId = a.DoctorId,
                DoctorName = a.Doctor?.Name ?? "N/A",
                ServiceName = a.Service?.Name ?? "Consultație",
            }).ToList();

            return appointmentDtos;
        }
        public List<AppointmentDto> GetAppointmentPatientHistory(Guid patientId)
        {
            var result = _context.Appointments
                .Where(a => a.PatientId == patientId)
                .Select(a => new AppointmentDto
                {
                    Id = a.Id,
                    Date = a.Date,
                    Status = a.Status,
                    DoctorId = a.DoctorId,
                    DoctorName = a.Doctor.Name,
                    ServiceName = a.Service.Name,
                    PatientId = a.PatientId
                })
                .ToList();

            return result;
        }
    }
}
