﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer.Interfaces;
using DataAccess.Models;
using DataAccess.Repository;

namespace BusinessLayer.Implementations
{
    public class ScheduleService : IScheduleService
    {
        private readonly IRepository<Appointment> _appointmentRepository;
        private readonly IRepository<Doctor> _doctorRepository;
        private readonly IRepository<DoctorService> _doctorServiceRepository;
        private readonly IRepository<Service> _serviceRepository;

        public ScheduleService(
            IRepository<Appointment> appointmentRepository,
            IRepository<Doctor> doctorRepository,
            IRepository<DoctorService> doctorServiceRepository,
            IRepository<Service> serviceRepository)
        {
            _appointmentRepository = appointmentRepository;
            _doctorRepository = doctorRepository;
            _doctorServiceRepository = doctorServiceRepository;
            _serviceRepository = serviceRepository;
        }

        public List<DateTime> GetAvailableSlots(Guid doctorId, DateTime forDate, TimeSpan slotDuration)
        {
            var startHour = new TimeSpan(8, 0, 0);
            var endHour = new TimeSpan(16, 0, 0);

            var allSlots = new List<DateTime>();
            for (var time = startHour; time + slotDuration <= endHour; time += slotDuration)
            {
                allSlots.Add(forDate.Date + time);
            }

            var appointments = _appointmentRepository
                .GetAll()
                .Where(a => a.DoctorId == doctorId && a.Date.Date == forDate.Date)
                .Select(a => a.Date)
                .ToList();

            return allSlots.Where(slot => !appointments.Contains(slot)).ToList();
        }

       /* public List<DateTime> GetAvailableSlots(Guid doctorId, DateTime forDate)
        {
            // Slot fara durata (implicit 30 min)
            return GetAvailableSlots(doctorId, forDate, TimeSpan.FromMinutes(30));
        }*/

        public Dictionary<Guid, List<DateTime>> GetAvailableSlotsBySpecialization(string specialization, DateTime forDate)
        {
            var doctors = _doctorRepository
                .GetAll()
                .Where(d => d.Specialization.Equals(specialization, StringComparison.OrdinalIgnoreCase))
                .ToList();

            var result = new Dictionary<Guid, List<DateTime>>();
            foreach (var doctor in doctors)
            {
                var availableSlots = GetAvailableSlots(doctor.Id, forDate, TimeSpan.FromMinutes(30));
                result[doctor.Id] = availableSlots;
            }

            return result;
        }

        public Dictionary<Guid, List<DateTime>> GetAvailableSlotsForService(Guid serviceId, DateTime forDate)
        {
           
            var service = _serviceRepository.GetById(serviceId);
            if (service == null)
            {
                throw new ArgumentException("Serviciul nu există.");
            }

            var duration = service.Duration;

            var doctorIds = _doctorServiceRepository
                .GetAll()
                .Where(ds => ds.ServiceId == serviceId)
                .Select(ds => ds.DoctorId)
                .Distinct()
                .ToList();

            var result = new Dictionary<Guid, List<DateTime>>();

            foreach (var doctorId in doctorIds)
            {
                var availableSlots = GetAvailableSlots(doctorId, forDate, duration);
                result[doctorId] = availableSlots;
            }

            return result;
        }
    }

}

